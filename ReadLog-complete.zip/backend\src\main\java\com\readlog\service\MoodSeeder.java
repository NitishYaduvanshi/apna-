package com.readlog.service;

import com.readlog.model.Mood;
import com.readlog.repository.MoodRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class MoodSeeder implements CommandLineRunner {
    private final MoodRepository moods;

    public MoodSeeder(MoodRepository moods) {
        this.moods = moods;
    }

    @Override
    public void run(String... args) {
        Map<String, String> catalog = new LinkedHashMap<>();
        catalog.put("Hopeful", "#c9a86c");
        catalog.put("Heartbroken", "#8b3a4a");
        catalog.put("Seen", "#4f7c8a");
        catalog.put("Restless", "#c0783a");
        catalog.put("Calm", "#6b8f71");
        catalog.put("Transformed", "#5c4d8a");
        catalog.put("Curious", "#3d6b9a");
        catalog.put("Nostalgic", "#a67c52");
        catalog.put("Anxious", "#7a5a3a");
        catalog.put("Joyful", "#d4af37");
        catalog.put("Angry", "#9b2c2c");
        catalog.put("Bittersweet", "#8a6a7b");
        catalog.forEach((name, color) -> {
            if (!moods.existsByNameIgnoreCase(name)) {
                Mood mood = new Mood();
                mood.setName(name);
                mood.setColor(color);
                moods.save(mood);
            }
        });
    }
}
