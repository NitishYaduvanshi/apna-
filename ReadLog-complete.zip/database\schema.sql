-- ReadLog PostgreSQL schema
-- Every book you've read, remembered the way you felt it.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name       VARCHAR(120) NOT NULL,
    email           VARCHAR(180) NOT NULL UNIQUE,
    password_hash   VARCHAR(120) NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE books (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title           VARCHAR(220) NOT NULL,
    author          VARCHAR(180) NOT NULL,
    genre           VARCHAR(80),
    status          VARCHAR(20) NOT NULL DEFAULT 'WANT_TO_READ'
                    CHECK (status IN ('WANT_TO_READ', 'READING', 'FINISHED')),
    rating          SMALLINT CHECK (rating IS NULL OR (rating BETWEEN 1 AND 5)),
    current_page    INTEGER NOT NULL DEFAULT 0 CHECK (current_page >= 0),
    total_pages     INTEGER CHECK (total_pages IS NULL OR total_pages > 0),
    started_on      DATE,
    finished_on     DATE,
    cover_color     VARCHAR(16) DEFAULT '#1b3a5c',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_books_user_status ON books(user_id, status);
CREATE INDEX idx_books_user_title ON books(user_id, title);

CREATE TABLE moods (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(40) NOT NULL UNIQUE,
    color       VARCHAR(16) NOT NULL
);

CREATE TABLE book_moods (
    book_id     UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    mood_id     UUID NOT NULL REFERENCES moods(id) ON DELETE CASCADE,
    PRIMARY KEY (book_id, mood_id)
);

CREATE TABLE reflections (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id     UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body        TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_reflections_book ON reflections(book_id, created_at DESC);

CREATE TABLE quotes (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id     UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    text        TEXT NOT NULL,
    page_number INTEGER,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_quotes_book ON quotes(book_id, created_at DESC);

CREATE TABLE reading_sessions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id     UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    pages_read  INTEGER NOT NULL CHECK (pages_read > 0),
    minutes     INTEGER CHECK (minutes IS NULL OR minutes > 0),
    felt        VARCHAR(40),
    logged_on   DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_user_date ON reading_sessions(user_id, logged_on DESC);
