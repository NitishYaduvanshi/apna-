package com.readlog.controller;

import com.readlog.dto.AuthDtos.AuthResponse;
import com.readlog.dto.AuthDtos.LoginRequest;
import com.readlog.dto.AuthDtos.RegisterRequest;
import com.readlog.model.User;
import com.readlog.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;

    public AuthController(AuthService auth) {
        this.auth = auth;
    }

    @PostMapping("/register")
    public AuthResponse register(@Valid @RequestBody RegisterRequest request) {
        return auth.register(request);
    }

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return auth.login(request);
    }

    @GetMapping("/me")
    public AuthResponse me() {
        User user = auth.currentUser();
        return new AuthResponse(null, user.getId(), user.getFullName(), user.getEmail());
    }
}
