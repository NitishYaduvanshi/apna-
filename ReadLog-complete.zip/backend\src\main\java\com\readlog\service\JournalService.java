package com.readlog.service;

import com.readlog.dto.JournalDtos.*;
import com.readlog.exception.ApiException;
import com.readlog.model.Book;
import com.readlog.model.Quote;
import com.readlog.model.ReadingSession;
import com.readlog.model.Reflection;
import com.readlog.model.User;
import com.readlog.repository.QuoteRepository;
import com.readlog.repository.ReadingSessionRepository;
import com.readlog.repository.ReflectionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class JournalService {
    private final BookService books;
    private final ReflectionRepository reflections;
    private final QuoteRepository quotes;
    private final ReadingSessionRepository sessions;
    private final AuthService auth;

    public JournalService(
            BookService books,
            ReflectionRepository reflections,
            QuoteRepository quotes,
            ReadingSessionRepository sessions,
            AuthService auth
    ) {
        this.books = books;
        this.reflections = reflections;
        this.quotes = quotes;
        this.sessions = sessions;
        this.auth = auth;
    }

    public List<ReflectionView> listReflections(UUID bookId) {
        books.owned(bookId);
        return reflections.findByBookIdOrderByCreatedAtDesc(bookId).stream()
                .map(r -> new ReflectionView(r.getId(), r.getBody(), r.getCreatedAt()))
                .toList();
    }

    @Transactional
    public ReflectionView addReflection(UUID bookId, ReflectionRequest req) {
        Book book = books.owned(bookId);
        User user = auth.currentUser();
        Reflection item = new Reflection();
        item.setBook(book);
        item.setUser(user);
        item.setBody(req.body());
        reflections.save(item);
        return new ReflectionView(item.getId(), item.getBody(), item.getCreatedAt());
    }

    public List<QuoteView> listQuotes(UUID bookId) {
        books.owned(bookId);
        return quotes.findByBookIdOrderByCreatedAtDesc(bookId).stream()
                .map(q -> new QuoteView(q.getId(), q.getText(), q.getPageNumber(), q.getCreatedAt()))
                .toList();
    }

    @Transactional
    public QuoteView addQuote(UUID bookId, QuoteRequest req) {
        Book book = books.owned(bookId);
        Quote item = new Quote();
        item.setBook(book);
        item.setUser(auth.currentUser());
        item.setText(req.text());
        item.setPageNumber(req.pageNumber());
        quotes.save(item);
        return new QuoteView(item.getId(), item.getText(), item.getPageNumber(), item.getCreatedAt());
    }

    @Transactional
    public void deleteQuote(UUID quoteId) {
        Quote quote = quotes.findByIdAndUserId(quoteId, auth.currentUser().getId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Quote not found"));
        quotes.delete(quote);
    }

    public List<SessionView> listSessions(UUID bookId) {
        books.owned(bookId);
        return sessions.findByBookIdOrderByLoggedOnDesc(bookId).stream().map(this::toView).toList();
    }

    @Transactional
    public SessionView addSession(UUID bookId, SessionRequest req) {
        Book book = books.owned(bookId);
        ReadingSession session = new ReadingSession();
        session.setBook(book);
        session.setUser(auth.currentUser());
        session.setPagesRead(req.pagesRead());
        session.setMinutes(req.minutes());
        session.setFelt(req.felt());
        session.setLoggedOn(req.loggedOn() == null ? LocalDate.now() : req.loggedOn());
        sessions.save(session);
        book.setCurrentPage(book.getCurrentPage() + req.pagesRead());
        if (book.getStartedOn() == null) {
            book.setStartedOn(session.getLoggedOn());
        }
        return toView(session);
    }

    private SessionView toView(ReadingSession s) {
        return new SessionView(s.getId(), s.getPagesRead(), s.getMinutes(), s.getFelt(), s.getLoggedOn(), s.getCreatedAt());
    }
}
