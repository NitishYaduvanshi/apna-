INSERT INTO moods (name, color) VALUES
    ('Hopeful',      '#c9a86c'),
    ('Heartbroken',  '#8b3a4a'),
    ('Seen',         '#4f7c8a'),
    ('Restless',     '#c0783a'),
    ('Calm',         '#6b8f71'),
    ('Transformed',  '#5c4d8a'),
    ('Curious',      '#3d6b9a'),
    ('Nostalgic',    '#a67c52'),
    ('Anxious',      '#7a5a3a'),
    ('Joyful',       '#d4af37'),
    ('Angry',        '#9b2c2c'),
    ('Bittersweet',  '#8a6a7b')
ON CONFLICT (name) DO NOTHING;
