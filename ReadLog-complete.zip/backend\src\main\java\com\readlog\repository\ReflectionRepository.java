package com.readlog.repository;

import com.readlog.model.Reflection;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface ReflectionRepository extends JpaRepository<Reflection, UUID> {
    List<Reflection> findByBookIdOrderByCreatedAtDesc(UUID bookId);
    long countByUserId(UUID userId);
}
