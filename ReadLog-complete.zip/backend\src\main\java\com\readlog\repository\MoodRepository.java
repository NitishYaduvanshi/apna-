package com.readlog.repository;

import com.readlog.model.Mood;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface MoodRepository extends JpaRepository<Mood, UUID> {
    Optional<Mood> findByNameIgnoreCase(String name);
    boolean existsByNameIgnoreCase(String name);
}
