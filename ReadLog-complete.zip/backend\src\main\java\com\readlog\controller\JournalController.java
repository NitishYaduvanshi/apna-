package com.readlog.controller;

import com.readlog.dto.JournalDtos.*;
import com.readlog.service.JournalService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/books/{bookId}")
public class JournalController {
    private final JournalService journal;

    public JournalController(JournalService journal) {
        this.journal = journal;
    }

    @GetMapping("/reflections")
    public List<ReflectionView> reflections(@PathVariable UUID bookId) {
        return journal.listReflections(bookId);
    }

    @PostMapping("/reflections")
    public ReflectionView addReflection(@PathVariable UUID bookId, @Valid @RequestBody ReflectionRequest request) {
        return journal.addReflection(bookId, request);
    }

    @GetMapping("/quotes")
    public List<QuoteView> quotes(@PathVariable UUID bookId) {
        return journal.listQuotes(bookId);
    }

    @PostMapping("/quotes")
    public QuoteView addQuote(@PathVariable UUID bookId, @Valid @RequestBody QuoteRequest request) {
        return journal.addQuote(bookId, request);
    }

    @GetMapping("/sessions")
    public List<SessionView> sessions(@PathVariable UUID bookId) {
        return journal.listSessions(bookId);
    }

    @PostMapping("/sessions")
    public SessionView addSession(@PathVariable UUID bookId, @Valid @RequestBody SessionRequest request) {
        return journal.addSession(bookId, request);
    }
}
