package com.readlog.model;

public enum BookStatus {
    WANT_TO_READ,
    READING,
    FINISHED
}
