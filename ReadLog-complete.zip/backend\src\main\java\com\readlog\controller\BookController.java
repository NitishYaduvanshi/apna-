package com.readlog.controller;

import com.readlog.dto.BookDtos.BookRequest;
import com.readlog.dto.BookDtos.BookView;
import com.readlog.dto.JournalDtos.StatsView;
import com.readlog.model.BookStatus;
import com.readlog.service.BookService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class BookController {
    private final BookService books;

    public BookController(BookService books) {
        this.books = books;
    }

    @GetMapping("/books")
    public List<BookView> list(@RequestParam(required = false) BookStatus status) {
        return books.list(status);
    }

    @GetMapping("/books/{id}")
    public BookView get(@PathVariable UUID id) {
        return books.get(id);
    }

    @PostMapping("/books")
    public BookView create(@Valid @RequestBody BookRequest request) {
        return books.create(request);
    }

    @PutMapping("/books/{id}")
    public BookView update(@PathVariable UUID id, @Valid @RequestBody BookRequest request) {
        return books.update(id, request);
    }

    @DeleteMapping("/books/{id}")
    public void delete(@PathVariable UUID id) {
        books.delete(id);
    }

    @GetMapping("/stats")
    public StatsView stats() {
        return books.stats();
    }
}
