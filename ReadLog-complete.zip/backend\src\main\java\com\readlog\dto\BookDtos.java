package com.readlog.dto;

import com.readlog.model.BookStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class BookDtos {
    public record BookRequest(
            @NotBlank @Size(max = 220) String title,
            @NotBlank @Size(max = 180) String author,
            String genre,
            BookStatus status,
            Integer rating,
            Integer currentPage,
            Integer totalPages,
            LocalDate startedOn,
            LocalDate finishedOn,
            String coverColor,
            List<String> moods
    ) {}

    public record MoodView(UUID id, String name, String color) {}

    public record BookView(
            UUID id,
            String title,
            String author,
            String genre,
            BookStatus status,
            Integer rating,
            int currentPage,
            Integer totalPages,
            LocalDate startedOn,
            LocalDate finishedOn,
            String coverColor,
            List<MoodView> moods,
            Instant createdAt,
            Instant updatedAt
    ) {}
}
