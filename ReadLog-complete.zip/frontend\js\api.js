const API = "http://localhost:8080/api";

function token() {
  return localStorage.getItem("readlog_token");
}

function currentUser() {
  const raw = localStorage.getItem("readlog_user");
  return raw ? JSON.parse(raw) : null;
}

function saveSession(data) {
  localStorage.setItem("readlog_token", data.token);
  localStorage.setItem("readlog_user", JSON.stringify({
    userId: data.userId,
    fullName: data.fullName,
    email: data.email
  }));
}

function logout() {
  localStorage.removeItem("readlog_token");
  localStorage.removeItem("readlog_user");
  location.href = "index.html";
}

function requireAuth() {
  if (!token()) {
    location.href = "index.html";
  }
}

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token()) {
    headers.Authorization = `Bearer ${token()}`;
  }
  const res = await fetch(`${API}${path}`, { ...options, headers });
  if (res.status === 204) {
    return null;
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(body.error || "Request failed");
  }
  return body;
}

function statusLabel(status) {
  return {
    WANT_TO_READ: "Want to read",
    READING: "Reading",
    FINISHED: "Finished"
  }[status] || status;
}

function formatDate(value) {
  if (!value) return "";
  return new Date(value).toLocaleDateString();
}
