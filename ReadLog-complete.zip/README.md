# ReadLog

Minor project web app: a private reading journal.

**Every book you've read, remembered the way you felt it.**

Student: Nitish Kumar · Guide: Utkarsh Dube · Department of BCA, G L Bajaj Institute of Management

## Stack

| Layer | Technology |
| --- | --- |
| Frontend | HTML, CSS, JavaScript |
| REST API | Java 17, Spring Boot 3.3 |
| Database | PostgreSQL 16 |

## Project layout

```
readlog/
  frontend/          static pages (open in a browser)
  backend/           Spring Boot Maven API
  database/          schema.sql + seed.sql
  docker-compose.yml PostgreSQL
```

## Run locally

1. Start PostgreSQL (Docker):

```bash
docker compose up -d
```

If you already have PostgreSQL, create database `readlog` with user/password `readlog` / `readlog`, then run `database/schema.sql` and `database/seed.sql`.

2. Start the API (Java 17 + Maven):

```bash
cd backend
mvn spring-boot:run
```

API: `http://localhost:8080`

Hibernate will create/update tables if they are missing. Mood tags are seeded on startup.

3. Open the frontend:

Open `frontend/index.html` in the browser, or serve the folder:

```bash
cd frontend
python -m http.server 5500
```

Then visit `http://localhost:5500`.

## REST endpoints

| Method | Path | Auth |
| --- | --- | --- |
| POST | `/api/auth/register` | no |
| POST | `/api/auth/login` | no |
| GET | `/api/auth/me` | JWT |
| GET | `/api/moods` | no |
| GET/POST | `/api/books` | JWT |
| GET/PUT/DELETE | `/api/books/{id}` | JWT |
| GET | `/api/stats` | JWT |
| GET/POST | `/api/books/{id}/reflections` | JWT |
| GET/POST | `/api/books/{id}/quotes` | JWT |
| GET/POST | `/api/books/{id}/sessions` | JWT |
| DELETE | `/api/quotes/{id}` | JWT |

Send `Authorization: Bearer <token>` after login.

Register body:

```json
{ "fullName": "Nitish Kumar", "email": "nitish@example.com", "password": "secret1" }
```

## What the app stores

- Books and reading status (want to read / reading / finished)
- Mood tags for how a book felt
- Short reflections (the journal)
- Quotes
- Reading sessions (pages, minutes, feeling that day)
