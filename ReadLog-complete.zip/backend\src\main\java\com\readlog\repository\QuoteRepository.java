package com.readlog.repository;

import com.readlog.model.Quote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface QuoteRepository extends JpaRepository<Quote, UUID> {
    List<Quote> findByBookIdOrderByCreatedAtDesc(UUID bookId);
    Optional<Quote> findByIdAndUserId(UUID id, UUID userId);
    long countByUserId(UUID userId);
}
