package com.readlog.repository;

import com.readlog.model.ReadingSession;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface ReadingSessionRepository extends JpaRepository<ReadingSession, UUID> {
    List<ReadingSession> findByBookIdOrderByLoggedOnDesc(UUID bookId);
    List<ReadingSession> findByUserIdOrderByLoggedOnDesc(UUID userId);
}
