package com.readlog.controller;

import com.readlog.service.JournalService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/quotes")
public class QuoteController {
    private final JournalService journal;

    public QuoteController(JournalService journal) {
        this.journal = journal;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable UUID id) {
        journal.deleteQuote(id);
    }
}
