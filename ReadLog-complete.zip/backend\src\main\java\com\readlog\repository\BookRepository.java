package com.readlog.repository;

import com.readlog.model.Book;
import com.readlog.model.BookStatus;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BookRepository extends JpaRepository<Book, UUID> {
    @EntityGraph(attributePaths = "moods")
    List<Book> findByUserIdOrderByUpdatedAtDesc(UUID userId);
    @EntityGraph(attributePaths = "moods")
    List<Book> findByUserIdAndStatusOrderByUpdatedAtDesc(UUID userId, BookStatus status);
    @EntityGraph(attributePaths = "moods")
    Optional<Book> findByIdAndUserId(UUID id, UUID userId);
    long countByUserId(UUID userId);
    long countByUserIdAndStatus(UUID userId, BookStatus status);
}
