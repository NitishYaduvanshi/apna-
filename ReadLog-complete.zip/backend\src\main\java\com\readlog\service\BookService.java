package com.readlog.service;

import com.readlog.dto.BookDtos.BookRequest;
import com.readlog.dto.BookDtos.BookView;
import com.readlog.dto.BookDtos.MoodView;
import com.readlog.dto.JournalDtos.StatsView;
import com.readlog.exception.ApiException;
import com.readlog.model.Book;
import com.readlog.model.BookStatus;
import com.readlog.model.Mood;
import com.readlog.model.User;
import com.readlog.repository.BookRepository;
import com.readlog.repository.MoodRepository;
import com.readlog.repository.QuoteRepository;
import com.readlog.repository.ReflectionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
public class BookService {
    private final BookRepository books;
    private final MoodRepository moods;
    private final ReflectionRepository reflections;
    private final QuoteRepository quotes;
    private final AuthService auth;

    public BookService(
            BookRepository books,
            MoodRepository moods,
            ReflectionRepository reflections,
            QuoteRepository quotes,
            AuthService auth
    ) {
        this.books = books;
        this.moods = moods;
        this.reflections = reflections;
        this.quotes = quotes;
        this.auth = auth;
    }

    public List<BookView> list(BookStatus status) {
        User user = auth.currentUser();
        List<Book> list = status == null
                ? books.findByUserIdOrderByUpdatedAtDesc(user.getId())
                : books.findByUserIdAndStatusOrderByUpdatedAtDesc(user.getId(), status);
        return list.stream().map(this::toView).toList();
    }

    public BookView get(UUID id) {
        return toView(owned(id));
    }

    @Transactional
    public BookView create(BookRequest req) {
        Book book = new Book();
        book.setUser(auth.currentUser());
        apply(book, req);
        return toView(books.save(book));
    }

    @Transactional
    public BookView update(UUID id, BookRequest req) {
        Book book = owned(id);
        apply(book, req);
        return toView(books.save(book));
    }

    @Transactional
    public void delete(UUID id) {
        books.delete(owned(id));
    }

    public StatsView stats() {
        UUID userId = auth.currentUser().getId();
        return new StatsView(
                books.countByUserId(userId),
                books.countByUserIdAndStatus(userId, BookStatus.FINISHED),
                books.countByUserIdAndStatus(userId, BookStatus.READING),
                books.countByUserIdAndStatus(userId, BookStatus.WANT_TO_READ),
                reflections.countByUserId(userId),
                quotes.countByUserId(userId)
        );
    }

    public Book owned(UUID id) {
        return books.findByIdAndUserId(id, auth.currentUser().getId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Book not found"));
    }

    private void apply(Book book, BookRequest req) {
        book.setTitle(req.title());
        book.setAuthor(req.author());
        book.setGenre(req.genre());
        if (req.status() != null) {
            book.setStatus(req.status());
        }
        book.setRating(req.rating());
        if (req.currentPage() != null) {
            book.setCurrentPage(req.currentPage());
        }
        book.setTotalPages(req.totalPages());
        book.setStartedOn(req.startedOn());
        book.setFinishedOn(req.finishedOn());
        if (req.coverColor() != null && !req.coverColor().isBlank()) {
            book.setCoverColor(req.coverColor());
        }
        if (req.moods() != null) {
            Set<Mood> set = new HashSet<>();
            for (String name : req.moods()) {
                Mood mood = moods.findByNameIgnoreCase(name)
                        .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "Unknown mood: " + name));
                set.add(mood);
            }
            book.setMoods(set);
        }
    }

    public BookView toView(Book book) {
        List<MoodView> moodViews = book.getMoods().stream()
                .map(m -> new MoodView(m.getId(), m.getName(), m.getColor()))
                .toList();
        return new BookView(
                book.getId(),
                book.getTitle(),
                book.getAuthor(),
                book.getGenre(),
                book.getStatus(),
                book.getRating(),
                book.getCurrentPage(),
                book.getTotalPages(),
                book.getStartedOn(),
                book.getFinishedOn(),
                book.getCoverColor(),
                moodViews,
                book.getCreatedAt(),
                book.getUpdatedAt()
        );
    }
}
