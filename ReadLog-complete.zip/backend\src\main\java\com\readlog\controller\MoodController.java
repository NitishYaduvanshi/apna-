package com.readlog.controller;

import com.readlog.dto.BookDtos.MoodView;
import com.readlog.repository.MoodRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/moods")
public class MoodController {
    private final MoodRepository moods;

    public MoodController(MoodRepository moods) {
        this.moods = moods;
    }

    @GetMapping
    public List<MoodView> list() {
        return moods.findAll().stream()
                .map(m -> new MoodView(m.getId(), m.getName(), m.getColor()))
                .toList();
    }
}
