package com.readlog.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

public class JournalDtos {
    public record ReflectionRequest(@NotBlank String body) {}
    public record ReflectionView(UUID id, String body, Instant createdAt) {}

    public record QuoteRequest(@NotBlank String text, Integer pageNumber) {}
    public record QuoteView(UUID id, String text, Integer pageNumber, Instant createdAt) {}

    public record SessionRequest(
            @NotNull @Min(1) Integer pagesRead,
            Integer minutes,
            String felt,
            LocalDate loggedOn
    ) {}

    public record SessionView(
            UUID id,
            int pagesRead,
            Integer minutes,
            String felt,
            LocalDate loggedOn,
            Instant createdAt
    ) {}

    public record StatsView(
            long totalBooks,
            long finished,
            long reading,
            long wantToRead,
            long reflections,
            long quotes
    ) {}
}
